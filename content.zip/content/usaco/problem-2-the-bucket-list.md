---
problemName: "Problem 2 The Bucket List"
contest: "USACO Bronze"
difficulty: "Bronze"
keyIdea: "Solution implementation"
language: "C++"
github: "https://github.com/TheAlphaJas/USACO-Sols"
---

## Solution

```cpp
#include <bits/stdc++.h>
using namespace std;
//author: von_Braun
#define ll long long
#define lli long long int
#define pb push_back
#define rep(var, start, num) for(ulli var = start; var <start + num; var++)
#define all(x) x.begin(), x.end()
#define ulli unsigned long long int
#define ull unsigned long long
bool sortbysec(const pair<ll,ll> &a,const pair<ll,ll> &b) { return (a.second < b.second); }

void solve() {
    int n,a,b,c;
    cin>>n;
    vector<tuple<int,int,int>> v;
    rep(i,0,n) {
        cin>>a>>b>>c;
        v.pb({a,b,c});
    }      
    vector<int> buckets(1005,0);
    rep(i,0,n) {
        buckets[get<0>(v[i])]+=get<2>(v[i]);
        buckets[1+get<1>(v[i])]-=get<2>(v[i]);
    }
    int ans=0;
    rep(i,1,buckets.size()-1) {
        buckets[i]+=buckets[i-1];
        ans=max(ans, buckets[i]);
    }
    cout<<ans<<endl;
}

int main() {
    //add quotes incase input output file
    freopen("blist.in","r",stdin);
    freopen("blist.out","w",stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int tc = 1;
    // cin >> tc;
    for (int t = 1; t <= tc; t++) {
        solve();
    }
}
```
